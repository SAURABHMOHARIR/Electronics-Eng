/*
Program Name:UART interfacing with LPC2148
Author Name: Moharir Saurabh Bhanudas              Roll No:36
Subject:Embedded Processor                         Class:TE Electronics
Year:2016-17
*/
#include "lpc214x.h"

#define FOSC	12000000

void BaudRate(unsigned long BaudRate)
{

unsigned int CountVal;
	VPBDIV = 0X01;  						                	// to choose pclk=cclk


CountVal = FOSC /(16 * BaudRate);   // Pg.150 LPC2148 User Manual (Rev. 4.0 2012 Edition)
	U0LCR |= (0x01<<7);   				// Divisor latch enable for setting of Fractoinal divisor value

	U0DLL = (CountVal & 0XFF); 			// Store DLL
	U0DLM = ((CountVal >> 8) & 0XFF);	// Store DLM

	if(BaudRate >=115200 && BaudRate < 460800 )
	{
		U0FDR |= (1<<0);   // DIVADDVAL = 1
		U0FDR |= (12<<4);  // MULVAL = 12
	}

	U0LCR &= ~(0x01<<7);
	U0TER |= (1<<7);		// UART0 Enable
}
