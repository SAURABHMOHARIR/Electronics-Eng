/*
Program Name:UART interfacing with LPC2148
Author Name: Moharir Saurabh Bhanudas              Roll No:36
Subject:Embedded Processor                         Class:TE Electronics
Year:2016-17
*/
#include "lpc214x.h"
#include "UART.h"

void Init_Uart0();
void Uart0_Tx(char Data);

void delay()
{
	int j;
	for (j=0;j<=1000;j++)
	{}
}

/* Main Program */
int main(void)
{
	unsigned char rdata,i;
	unsigned char A[5]={'H','E','L','L','O'};
	Init_Uart0();						// UART0 initialized with Baudrate=9600


		 for (i=0;i<=4;i++)
		 {
		rdata = A[i];					// Receive character from UART0 input from HyperTerminal or Teraterm
		Uart0_Tx(rdata);
		delay();
		 }
		 return 0;
	}
/***************************************************************************
                                UART0 Functions
******************************************************************************/
/** This Program initialize the UART0 **/
void Init_Uart0()
{

	//PINSEL0 &= ~0x0F;  	// Clearing GPIO Values for Pin0.0 and P0.1 to config it for UART0
	PINSEL0 = 0x05;   	// Configure P0.0 and P0.1 for UART0 TxD and RxD
   // IO0DIR &= ~0x02;   	// Direction: P0.1 RX as input
    IO0DIR |= 0x01;    	// Direction: P0.0 TX as Output

	U0FCR = 0X07;		// Reset FIFO and Enable it

	U0LCR |= 0x03;		// databits: 8, parity: No, stopbit: 1

	BaudRate(9600);
}
/** This Function is used to transmit data using UART0 **/
void Uart0_Tx(char Data)
{
	while(!(U0LSR & 0x20));	// Wait until UART0 FIFO gets empty
	U0THR = Data;			// Transmit data using Transmit holding register
}

