/*
Program Name:DAC interfacing with LPC2148
*/
#include "lpc214x.h"

void delay()
{
	int i,j;
	for(i=0;i<2000;i++)
	{for(j=0;j<10;j++);}
}

/* Main Program 
1)Square Wave Generation
*/
int main(void)
{

PINSEL1=0x00080000;
IODIR0=0xFFFFFFFF;

	while(1){
	
		DACR=((0x0FF<<6)|(1<<16));
		delay();
  	DACR=((0x000<<6)|(1<<16));
		delay();
	}
	return 0;
}



/* Main Program 
2)Ramp Wave Generation
*/
void main()
{
	PINSEL1=0x00080000;
IODIR0=0xFFFFFFFF;
	int i=0;
	while(1){
	
		DACR=(i<<6)| 0x00010000;
		i++;
		delay();
  if(i==1024){
		i=0;
	}
	return 0;
  }
	}

	
	
	
	
	
	
	
	
	
/* Main Program 
2)Sine Wave Generation
*/

void main()
{
	PINSEL1=0x00080000;
  IODIR0=0xFFFFFFFF;
	unsigned int i = 0;
  unsigned int datatable[25]={0x00,0x0F,0x1F,0x2F,0x3F,0x4F,0x5F,0x6F,0x7F,0x8F,
 0x9F,0xAF,0xBF,0xCF,0xDF,0xEF,0xFF,0x100,0x150,0x200,0x250,0x300,0x350,0x400};
	while(1){
	for(i=0;i<25;i++){
				DACR = (datatable[i]<<6 );
	}
  }
	}