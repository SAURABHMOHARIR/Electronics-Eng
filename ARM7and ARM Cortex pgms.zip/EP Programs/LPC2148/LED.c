/*
Program Name:LED interfacing with LPC2148
Author Name: Moharir Saurabh Bhanudas
Roll No:36
Subject:Embedded Processor
Class:TE Electronics
Year:2016-17
*/


#include<lpc214x.h>

void delay()
{
  int i;
	for(i=0;i<200000;i++);

}
int main()
{
	PINSEL0=0X00;
	IODIR0=0XFF;
	while(1)
	{
		IOSET0=0XFF;
		delay();
		IOCLR0=0XFF;
		delay();
	}
}