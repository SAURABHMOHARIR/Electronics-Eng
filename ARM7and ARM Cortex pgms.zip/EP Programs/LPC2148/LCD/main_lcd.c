/*
Program Name:LCD interfacing with LPC2148
Author Name: Moharir Saurabh Bhanudas
Roll No:36
Subject:Embedded Processor
Class:TE Electronics
Year:2016-17
*/

#include "lpc214x.h"

void Delay(unsigned loops)
{
	unsigned i;
	for (i=0; i<loops; i++) {}
}

/*** This function is used to Toggle Enable pin for LCD. ***/
void Toggle_En(void)
{
	Delay(1000);	// Delay larger for 8bit mode
	IO0SET = 0X00000080;	// Enable pin = 1;
	Delay(1000);	// Delay larger for 8bit mode
	IO0CLR = 0X00000080;	// Enable pin = 0;
}


/*** This function is used to pass command to LCD. ***/
void Lcd_Cmd(char lcdcmd)
{
	IO0CLR = 0x00000020; 		// Clear RS Pin ; It will work as command

	IO0SET = lcdcmd << 8;   	//
	IO0CLR = ~lcdcmd << 8;
	Toggle_En();				// Toggle Enable pin to latch command
}

/*** This function is used to pass data to LCD. ***/
void Lcd_Data(char lcddata)
{
	IO0SET = 0x00000020; 		// Set RS Pin ; It will work as data
	IO0SET = lcddata << 8;   	//
	IO0CLR = ~lcddata << 8;  	// Data should be shifted to 8th pin// remaining bits 0
		Toggle_En();				// Toggle Enable pin to latch data

}

/*** This function is used to initialize LCD. ***/
void Lcd_Init(void)
{
	PINSEL0 &= ~0xFFFFFC00; // LCD 8 Data pins and 3 control pins as GPIO
    IO0DIR = 0x0000FFE0;  	// LCD is used in 8 bit mode; Pin12-15 are used for data lines
   	Delay(1000);
   	Lcd_Cmd(0x0E); Delay(1000);	// clear display

	Lcd_Cmd(0x01); Delay(1000);	// clear display

	Lcd_Cmd(0x38); Delay(1000);	// 8 BIT MODE

}


/* Main Program */
int main(void)
{
	unsigned char string[]={'R','O','L','L','N','O',':','3','6'};
		int i,data1;
		Lcd_Init();               // Initialize LCD in 8bit mode
		Lcd_Cmd(0x01);            // LCD clear cmd

		Lcd_Cmd(0x80);  		  // LCD Line1 cmd

		for (i=0;i<=8;i++)
		{
			data1=string[i];
			Lcd_Data(data1);
		}

	while(1);
	return 0;
}



