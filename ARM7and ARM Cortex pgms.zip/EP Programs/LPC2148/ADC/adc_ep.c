/*
Program Name:ADC(internal) interfacing with LPC2148
Author Name: Moharir Saurabh Bhanudas           Roll No:36
Subject:Embedded Processor                      Class:TE Electronics
Year:2016-17
*/
#include "lpc214x.h"
#include "LCD.h"


/** This function is used to Initialize ADC channel ADC0.1 **/

void Adc_Init(void)
{
	PINSEL1 |= 0x01000000;	// configure GPIO pin as ADC0.1
	VPBDIV = 1;             // PCLK = FOSC
	AD0CR = 0x00200302;		// AD0.1 Enable, PDN =1, PClk/4
}


/* This function is used to read ADC channel ADC0.1 **/
void Read_Adc()
{
	int i,x;
int Value;


	AD0CR |= 0x01000000;	// Start ADC Channel Conversion

	while((AD0GDR & 0x80000000)!=0x80000000); // Check for ADC Conversion to Complete; Check Done bit
	Value = (AD0GDR & 0x0000FFC0)>>6;

	for(i=0;i<10;i++)
	 {
	    x=Value & 0x200;
	   if(x==0)
	   {
		   Lcd_Data('0');
	   }
	   else
	   {
		   Lcd_Data('1');
	   }
	  Value<<=1;
	 }
	       // delay();

	    }


/* Main Program */
int main(void)
{

	Lcd_Init();
	Adc_Init();
	Lcd_Cmd(0x01);					// LCD clear cmd
	Lcd_Cmd(0x80);					// LCD first line cmd
	Lcd_String("ADC Value ");		// msg string
	Lcd_Cmd(0xC0);				// LCD second line cmd
	Lcd_String("CH0.1:");			// msg string

	Read_Adc();

     	while(1);
}



