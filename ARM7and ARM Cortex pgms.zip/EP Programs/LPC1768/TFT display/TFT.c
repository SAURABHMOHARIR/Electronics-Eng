/*
Program Name:TFT Display interfacing with LPC1768
Author Name: Moharir Saurabh Bhanudas              Roll No:36
Subject:Embedded Processor                         Class:TE Electronics
Year:2016-17
*/
#include "lpc_system_init.h"

#include "lpc17xx.h"

int main(void)
{
	int i;
	System_Init();

    GLCD_Clear (White);
    GLCD_Display_String(7,2,"Telekinesis 2K17");

    GLCD_PutPixel(180,120,Black);
    GLCD_PutPixel(181,120,Black);
    GLCD_PutPixel(180,121,Black);
    GLCD_PutPixel(181,121,Black);

    GLCD_PutPixel(90,180,Red);
    GLCD_PutPixel(91,180,Red);
    GLCD_PutPixel(90,181,Red);
    GLCD_PutPixel(91,181,Red);


    for(i=0;i<100;i++){
       GLCD_PutPixel(190+i,120,Red);
       GLCD_PutPixel(191+i,120,Red);
       GLCD_PutPixel(190+i,121,Red);
       GLCD_PutPixel(191+i,121,Red);
    }


	while (1);

}
