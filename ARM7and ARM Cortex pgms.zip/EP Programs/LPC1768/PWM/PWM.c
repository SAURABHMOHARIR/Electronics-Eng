/*
Program Name:Generation of PWM signal for motor control using LPC1768
Author Name: Moharir Saurabh Bhanudas              Roll No:36
Subject:Embedded Processor                         Class:TE Electronics
Year:2016-17
*/
#include "LPC17xx.h"

int main(void)
{
   // LPC_WDT->WDMOD &= ~0x01;  // Disable Watchdog
  //  SystemInit();             // Initialize system and update core clock

    /* Turn On MCPWM PCLK */
    LPC_SC->PCONP |= (1<<17);

    /* Clear two bit at bit position and set div value PCLK/4 */
   // LPC_SC->PCLKSEL1 &= ~(0x03<<30);
    LPC_SC->PCLKSEL1 |=0x00; // (0<<30);

    /* Configure Pins */
    LPC_PINCON->PINSEL3 = (1<<6)|(1<<12);

    /* Configure PWM */
    LPC_MCPWM->MCTIM0 = 0;         // channel timer counter value
    LPC_MCPWM->MCPER0 = 500;       // channel period value
    LPC_MCPWM->MCPW0 = 450;        // channel pulse width value
    LPC_MCPWM->MCCON_CLR = 0x02;   // Edge align mode for channel 0
    LPC_MCPWM->MCCON_CLR = 0x04;   // channel polarity passive low
    LPC_MCPWM->MCCON_CLR = 0x08;   // Disable Deadtime
    LPC_MCPWM->MCCON_CLR = 0x10;   // Channel update enabled

    /*Start PWM Channels */
    LPC_MCPWM->MCCON_SET = 0x01;

	while(1);
    return 1;
}


