/*
Program Name:Interfacing of RGB LED with LPC1768
Author Name: Moharir Saurabh Bhanudas              Roll No:36
Subject:Embedded Processor                         Class:TE Electronics
Year:2016-17
*/							 		 
//Include Controller specific header file
#include <LPC17xx.H>   /* LPC17xx definitions */

void delay(int count)
{
  int j=0,i=0;

  for(j=0;j<count;j++)
  {
    for(i=0;i<3500;i++);
  }
}
int main (void) 
{
int i;
	//Set the direction of ports pins as output
  LPC_GPIO0->FIODIR = 0x1 << 25;
	LPC_GPIO2->FIODIR = 0x3 << 2;	
	
	while(1)
	{
	LPC_GPIO0->FIOCLR = 1<<25;
	LPC_GPIO2->FIOSET = 1<<2;
	delay(1);
	
		LPC_GPIO2->FIOCLR = 1<<2;
		LPC_GPIO2->FIOSET = 1<<3;
		delay(3);
		
				// delay(1000);
			LPC_GPIO2->FIOCLR = 1<<3;
	
	
			LPC_GPIO0->FIOSET = 1<<25;
				 delay(2);
				 
}
}
