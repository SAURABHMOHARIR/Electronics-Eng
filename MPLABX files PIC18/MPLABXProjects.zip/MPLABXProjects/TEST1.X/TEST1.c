/*
 * File:   TEST1.c
 * Author: SAURABH MOHARIR
 *
 * Created on April 10, 2017, 8:36 PM
 */


#include<pic18f4550.h>
#define _XTAL_FREQ=20000000
//#define BA PORTAbits.RA0
/*void delay(){
    int i,j;
    for(i=0;i<10000;i++);
       
}*/



void main(void){
//TRISAbits.RA5=1;//INPUTS
TRISCbits.RC0=0;
TRISCbits.RC1=0;
TRISD=0x00;
while(1)
{
    PORTD=0xFF;
    PORTCbits.RC0=1;
    PORTCbits.RC1=1;
    
}
}