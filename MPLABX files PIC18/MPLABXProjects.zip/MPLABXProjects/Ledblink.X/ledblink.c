#include<PIC18F4550.h>
#define LED PORTCbits.RC7
#define SW PORTAbits.RA0
void delay()
{
	unsigned int i,j;
	for(i=0;i<10000;i++)
        {
            for(j=0;j<10;j++);
        }
}
void main()
{
    TRISCbits.RC7=0;
    TRISAbits.RA0=1;
    if(SW==1){
       LED=1;
    }
    else
        LED=0;
 
}