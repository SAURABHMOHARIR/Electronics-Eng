#include <16F876.h>
#fuses HS,NOWDT,NOPROTECT,NOLVP
#use delay(clock=20000000)
#use rs232(baud=9600, xmit=PIN_C6, rcv=PIN_C7)
//#include <string.h>
#include <STDLIB.H>
#include <lcdrabah.c>
#define use_portb_lcd TRUE
void     main() {
long     a=0,b=0,c=0;

char     string[30],password[30];
         strcpy(password,"picc");
         lcd_init();
start:   printf("\fPassword: ");
         lcd_putc("\fPassword: ");
         gets(string);
         printf(lcd_putc,"\f%4s",string);
         if(!strcmp(string,password)) printf("OK password correct\r");
         else{
         printf("Erreur ");
         lcd_putc("\nErreur ");
         delay_ms(1000);
         goto start;}
rep:     printf("\rA: ");
         gets(string);
         a=strtod(string,&c);
         printf("B: ");
         gets(string);
         b=strtod(string,&c);
         printf("La somme A+B=%lu\r",a+b);
         printf(lcd_putc,"\fA+B=%lu\r",a+b);
         printf("Le produit A*B=%lu\r",a*b);
         printf(lcd_putc,"\nA*B=%lu\r",a*b);
         goto rep;

/*
         printf(  "A:");
         a=getc()-48;
         a=getc()-48;
         a=getc()-48;
         printf("\rB");
         b=getc()-48;
         printf("\rLe produit A*B=%d",a*b);
*/
}
