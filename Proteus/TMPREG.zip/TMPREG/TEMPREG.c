//TEMPREG by Guelbert Cool 10/11/2012
#include <18F4550.h> 
#device adc=10    // Set ADC resolution to 10Bit for lm35
#fuses HSPLL,MCLR,NOWDT,NOPROTECT,NOLVP,NODEBUG,USBDIV,PLL5,CPUDIV1,VREGEN,NOPBADEN
#use delay(clock=20000000)    
//#define use_portb_lcd TRUE
#include "LCD.C"
#include "usb_cdc.h"
#include "usb_desc_cdc.h"
#include "stdlib.h"
#define PORTB  0x0f81
#define HEATER PIN_B4    
#define BUZZER PIN_B5
#define LAMPE  PIN_B6
#define MOTOR  PIN_B7
char LETRA[],string[4];
int temp,set_temp=60,MAX=20;
int digital_reading;  // ADC resolution is 10Bit, an 8Bit integer is not enough to hold the reading
boolean power=false;
//-fuctions---------------------------------------------------------

void put_led_state(){
            if(usb_cdc_putready()){
            usb_cdc_putc('\0');
            usb_cdc_putc(*portb);}  //C++ rx_tab[0]
} 

void put_temp(){
            if(usb_cdc_putready()){
            usb_cdc_putc(temp/2);   //C++ rx_tab[1]    
            usb_cdc_putc(set_temp);}//C++ rx_tab[2]
} 
void put_power_state(){
            if(usb_cdc_putready()){
            usb_cdc_putc(power);}   //C++ rx_tab[3]
} 
void inttostr(int x){
   itoa(x,10, string);
}
void LCD_PRNT(){
   lcd_putc("\ftemp    = ");
   inttostr((int)(temp*0.4883)); 
   lcd_putc(string[0]);
   lcd_putc(string[1]);
   lcd_putc(string[2]);
   lcd_putc("\nSet temp= ");
   inttostr(set_temp); 
   lcd_putc(string[0]);
   lcd_putc(string[1]);
   lcd_putc(string[2]);
}

//--main code-------------------------------------------------------
void main() {
      setup_adc(ADC_CLOCK_INTERNAL); // initialize ADC with a sampling rate of Crystal/4 MHz
      setup_adc_ports(AN0|VSS_VDD);
      set_adc_channel(0);            // point ADC to channel 0 for ADC reading 
      lcd_init();
      usb_cdc_init();
      usb_init();    
      output_high(PIN_C0);
      output_low(PIN_C1);
   
      while(!usb_cdc_connected())
      do{
      //lm35
      digital_reading = read_adc();    // capture current temperature reading
      DELAY_MS(100);
      if(temp != digital_reading){
      temp = digital_reading;
      put_led_state();
      put_temp();
      put_power_state();
      LCD_PRNT();
      }
      
      usb_task();
      
      if (usb_enumerated()){        
            output_low(PIN_C0); 
            output_high(PIN_C1);         
      if(usb_cdc_kbhit()){             
        LETRA=usb_cdc_getc();
            switch(LETRA){
            case  130  : break;
            case  131  : output_toggle(PIN_B0); break;
            case  132  : output_toggle(PIN_B1); break;
            case  133  : output_toggle(PIN_B2); break;
            case  134  : output_toggle(PIN_B3); break;
            case  135  : output_toggle(HEATER);if(*portb&0x10)lcd_putc("\fHEATER  ON");else lcd_putc("\fHEATER  OFF") ; break;
            case  136  : output_toggle(BUZZER);if(*portb&0x20)lcd_putc("\fBUZZ  ON");else lcd_putc("\fBUZZ  OFF") ; break;
            case  137  : output_toggle(LAMPE);if(*portb&0x40)lcd_putc("\fLAMP  ON");else lcd_putc("\fLAMP  OFF") ; break;
            case  138  : output_toggle(MOTOR);if(*portb&0x80)lcd_putc("\fMOTOR ON");else lcd_putc("\fMOTOR OFF") ; break;
            case  139  : power=!power;lcd_putc("\fPOWER ON") ; break;
            default    : set_temp=letra;LCD_PRNT();break;
        }
        put_led_state();//    1 BYTE
        put_temp();//         2 BYTE
        put_power_state();//  1 BYTE
        }               
      }
      if(power){
      if(temp*0.4883<set_temp)
      OUTPUT_HIGH(HEATER);else OUTPUT_low(HEATER);
      if(temp*0.4883>set_temp+MAX)
      OUTPUT_HIGH(BUZZER);else OUTPUT_low(BUZZER);
      }
      }while (true);
}
